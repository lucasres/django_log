# Description

This middleware log All request(GET,POST), response and errors. This log will save in file.

# Get Started

Install the project
```
    pip install django-log
```
 
Set in your settings.py the path you will want store the log. 
```
    LOG_PATH=/you/path/
```
