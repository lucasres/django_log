# Description

This middleware log All request(GET,POST), response and errors. This log will save in file.

# Get Started



# Configuration
 
Set in your settings.py the path you will want store the log. 
```
    LOG_FILE=/you/path/request_response.txt
```

Remeber you must include the name of file and extension. This works fine with txt 